---
title: "Parameterized Report for Shiny"
output: html_document
params:
  text: 'NULL'
---

**Version history:**

08/13/2019 - first version online.
